//
//  ViewController.swift
//  Devanaboyina_SearchApp
//
//  Created by student on 3/3/22.
//



import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var searchOption: UIButton!

    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var prevImage: UIButton!
    
    @IBOutlet weak var nextImage: UIButton!
    
    @IBOutlet weak var topicinfoText: UITextView!
    
    @IBOutlet weak var resetAction: UIButton!
    
    var imgCount = 0;
    var topic: Int = -1
    var update : Int = -1
    var arr = [
        ["Bently","Benz","tata","Lamborghini","Tesla"],["Biryani","Burger","Pasta","Pongal","GulabJamun"],["Charminar","EiffelTower","GolcondaFort","QutubMinar","Tajmahal"]]
    
    var car_keywords = ["cars","carbrands","bently","benz","lamborghini","tata","tesla","automobiles","branded cars"]
    
    var food_keywords =
    ["foods","biryani","burger","gulabJamun","pasta","pongal","cuisines"]
    var monuments_keywords = ["monuments","Famous Places", "charminar","qutubMinar","tajmahal","golcondaFort","eiffelTower","Historic Buildings"]
    var topics_array = [["Bentley Motors Limited is a British manufacturer and marketer of luxury cars and SUVs, and a subsidiary of the Volkswagen Group since 1998. Headquartered in Crewe, England, the company was founded as Bentley Motors Limited by W. O","Mercedes-Benz, commonly referred to as just Mercedes, is a German luxury automotive marque. Both Mercedes-Benz and Mercedes-Benz AG are headquartered in Stuttgart, Baden-Württemberg, Germany. Mercedes-Benz produces consumer luxury vehicles and commercial vehicles","Tata Motors Limited is an Indian multinational automotive manufacturing company, headquartered in the city of Mumbai, India which is part of Tata Group. The company produces passenger cars, trucks, vans, coaches, buses, luxury cars, sports cars, construction equipment.","Automobile Lamborghini S.p.A. is an Italian brand and manufacturer of luxury sports cars and SUVs based in Sant'Agata Bolognese. The company is owned by the Volkswagen Group through its subsidiary Audi.","Tesla, Inc. is an American electric vehicle and clean energy company based in Austin, Texas. Tesla designs and manufactures electric cars, battery energy storage from home to grid-scale, solar panels and solar roof tiles, and related products and services"],
        ["Biryani is a mixed rice dish originating among the Muslims of the Indian subcontinent. It is made with Indian spices, rice, either with meat, or eggs or vegetables such as potatoes.","A hamburger is a food consisting of fillings —usually a patty of ground meat, typically beef—placed inside a sliced bun or bread roll."," Pasta is a type of food typically made from an unleavened dough of wheat flour mixed with water or eggs, and formed into sheets or other shapes, then cooked by boiling or baking.","Pongal, also known as pongali or huggi, is an Indian rice dish. In Tamil, 'pongal' means '   boil' or 'bubbling up'. The two varieties of pongal are chakarai pongal, which is sweet, and venn pongal, which is savoury and made with clarified butter.","Gulab jamun is a milk-solid-based sweet, originating in the Indian subcontinent and a type of mithai popular in India, Nepal, Pakistan, the Maldives, and Bangladesh, as well as Myanmar. It is the national dessert of Pakistan"],
        ["The Charminar constructed in 1591, is a monument located in Hyderabad, Telangana, India. The landmark has become known globally as a symbol of Hyderabad and is listed among the most recognised structures in India","The Eiffel Tower is a wrought-iron lattice tower on the Champ de Mars in Paris, France. It is named after the engineer Gustave Eiffel, whose company designed and built the tower.","Golconda Fort, located in Hyderabad, Telangana, India. Because of the vicinity of diamond mines, especially Kollur Mine, Golconda flourished as a trade centre of large diamonds, known as the Golconda Diamonds.","The Qutub Minar, also spelled as Qutb Minar and Qutab Minar, is a minaret and 'victory tower' that forms part of the Qutb complex, which lies at the site of Delhi’s oldest fortified city, Lal Kot, founded by the Tomar Rajputs.","The Taj Mahal, is an ivory-white marble mausoleum on the right bank of the river Yamuna in the Indian city of Agra. It was commissioned in 1632 by the Mughal emperor Shah Jahan to house the tomb of his favourite wife, Mumtaz Mahal; it also houses the tomb of Shah Jahan himself."]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
   
        searchOption.isEnabled = false
        nextImage.isHidden = true
        prevImage.isHidden = true
        resetAction.isHidden = true
        resultImage.image = UIImage(named: "startpage")

    }


    @IBAction func searchFieldAction(_ sender: Any) {
        searchOption.isEnabled = true
    }
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        if(monuments_keywords.contains(searchTextField.text!)){
            topic = 2
            imgCount = 0
            buttonsDisable()
        }
        else if(car_keywords.contains(searchTextField.text!)){
            topic = 0
            imgCount = 0
            buttonsDisable()
        }
        else if(food_keywords.contains(searchTextField.text!)){
            topic = 1
            imgCount = 0;
            buttonsDisable()
        }
        else{
            topic = -1
            resultImage.image = UIImage(named: "startpage")
            topicinfoText.text = "Matches not Found."
            resetAction.isHidden = true
            nextImage.isHidden = true
            prevImage.isHidden = true
        }
        
        if(topic != -1)
        {
            prevImage.isEnabled = false
            nextImage.isEnabled = true
            update = arr[topic].count
            resultImage.image = UIImage(named: arr[topic][0])
            topicinfoText.text = topics_array[topic][0]
        }
        
    }
    
    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
            nextImage.isEnabled = true;
            imgCount -= 1
            resultImage.image = UIImage(named: arr[topic][imgCount])
            topicinfoText.text = topics_array[topic][imgCount]
            if(imgCount == 0){
                        prevImage.isEnabled = false
                }
    
    }
    
    @IBAction func ShowNextImagesBtn(_ sender: UIButton) {
            prevImage.isEnabled = true
            imgCount += 1
            resultImage.image = UIImage(named: arr[topic][imgCount])
            topicinfoText.text = topics_array[topic][imgCount]
            if(imgCount == update-1){
                nextImage.isEnabled = false
            }
    }
    
    @IBAction func resetButton(_ sender: Any) {
        nextImage.isHidden = true
        prevImage.isHidden = true
        resetAction.isHidden = true
        searchTextField.text = ""
        searchOption.isEnabled = false
        topicinfoText.text = ""
        resultImage.image = UIImage(named: "startpage")
        
    }
    func buttonsDisable(){
        nextImage.isHidden = false
        prevImage.isHidden = false
        resetAction.isHidden = false
    }
    


}


